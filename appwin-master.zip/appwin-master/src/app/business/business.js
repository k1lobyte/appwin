"use strict";
var Business = (function () {
    function Business() {
    }
    return Business;
}());
exports.Business = Business;
//# sourceMappingURL=business.js.map