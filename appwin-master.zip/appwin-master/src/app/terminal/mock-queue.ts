import { QueueEntry } from './queueentry';

export var QUEUE: QueueEntry[] = [
    {"id":1,"name":"Alec Swanson","email":"aleceswanson@gmail.com","phone":"8139955280", "timeWaiting":15},
    {"id":2,"name":"Hwoard Tern","email":"esdfgyt@gmail.com","phone":"3453134514", "timeWaiting":12},
    {"id":3,"name":"Alie Hilton","email":"asdas.rwerwe@gmail.com","phone":"6786678676", "timeWaiting":10},
    {"id":4,"name":"Sup Mydaug","email":"ssthwrt12@gmail.com","phone":"2456456456", "timeWaiting":8},
    {"id":5,"name":"Hilly McNilly","email":"adsfatr5@gmail.com","phone":"2342342334", "timeWaiting":7},
    {"id":6,"name":"Gerad Bort","email":"DSFWERY@gmail.com","phone":"2346878753", "timeWaiting":5},
];
