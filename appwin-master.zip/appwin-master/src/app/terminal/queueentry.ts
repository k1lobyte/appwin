
export class QueueEntry {
    id: number;
    name: string;
    email: string;
    phone: string;
    timeWaiting: number;
}
