import { Component }    from '@angular/core';

@Component({
    selector: 'add-entry',
    templateUrl: './add-entry.component.html',
})

export class AddEntryComponent {

}
