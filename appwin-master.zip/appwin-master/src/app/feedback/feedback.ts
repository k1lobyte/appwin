export class Feedback {
   id: string;
   appointment_Id: string;
   company_id: string;
   employee_Id: string;
   rating: number;
   comment: string;
}
