"use strict";
var Service = (function () {
    function Service() {
    }
    return Service;
}());
exports.Service = Service;
//# sourceMappingURL=service.js.map