export class Service {
  id: string;
  company_id: string;
  name: string;
  description: string;
  estDuration: number;
}
