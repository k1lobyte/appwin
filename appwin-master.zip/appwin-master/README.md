**AppWin Front-End Service**

This Express App is the API for our appointment service. This was made for COP 4331 Processes of Object Oriented Software Development at University of Central Florida.

Team Members include:<br>
Alec Swanson https://github.com/k1lobyte <br>
Brooke Norton https://github.com/nortonbrooke <br>
Adam Albright https://github.com/rehket<br>
Francisco Tirado Perez<br>
Huy Quang Vo<br>
Omar Hamouda<br>
 
 This repository contains the front-end service for our app. The back-End Client can be found at: https://github.com/Rehket/AppWinDataService
 
**Build Instructions**

Requirements:<br>
Node.js<br>
npm<br>

Clone the Repository.

Install the Dependencies with: _npm install_.

Start the Front-End Server with the command: _npm start_
